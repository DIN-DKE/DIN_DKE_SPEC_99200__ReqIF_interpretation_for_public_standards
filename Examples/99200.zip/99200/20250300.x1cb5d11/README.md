� DIN Deutsches Institut f�r Normung e. V. ist Inhaber aller ausschlie�lichen Rechte weltweit --- alle Rechte der Verwertung, gleich in welcher Form und welchem Verfahren, sind weltweit DIN e. V. vorbehalten.

To obtain the PDF download for the rendered reference version free of charge, use the following link:

https://www.dinmedia.de/en/technical-rule/din-dke-spec-99200/389211467